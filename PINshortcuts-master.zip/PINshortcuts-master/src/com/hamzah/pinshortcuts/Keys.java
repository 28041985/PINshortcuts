package com.hamzah.pinshortcuts;

public class Keys {

	public static final String PREF = "pref";
	public static final String NORMAL_PASSWORD = "normal_password";
	public static final String PNAME = "pname";
	public static final String NOT_SET="notsetandthisisrandomstringtomakeitharderforittoberight";
	public static final String NORMAL_PATTERN = "normal_pattern";
	public static final String EDITING = "editing";
}
