PINshortcuts
============

Xposed module allowing you to use custom PIN codes or patterns to launch apps from the lockscreen
